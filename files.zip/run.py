"""
python run.py \
  --bu-list-url "https://your-org.crm.dynamics.com/...businessunit" \
  --tasks '[
    {"type": "parent_bu", "name": "Contoso"},
    {"type": "child_bu",  "name": "Sales West",  "parent": "Contoso"},
    {"type": "child_bu",  "name": "Sales East",  "parent": "Contoso"}
  ]'
"""
import asyncio, argparse, json, logging, os
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), "pp_bu_agent", ".env"))
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")


async def main(bu_list_url: str, tasks: list[dict]):
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService
    from google.genai import types as genai_types
    from pp_bu_agent import root_agent

    svc = InMemorySessionService()
    runner = Runner(agent=root_agent, app_name="pp_bu_agent", session_service=svc)

    session = await svc.create_session(
        app_name="pp_bu_agent", user_id="operator",
        state={"bu_list_url": bu_list_url, "tasks": json.dumps(tasks)},
    )

    print(f"\n{'='*60}")
    for i, t in enumerate(tasks):
        p = f" under '{t['parent']}'" if t.get("parent") else ""
        print(f"  {i+1}. [{t['type']}] '{t['name']}'{p}")
    print(f"{'='*60}\n")

    async for ev in runner.run_async(
        session_id=session.id, user_id="operator",
        new_message=genai_types.Content(
            role="user", parts=[genai_types.Part(text="Execute pipeline")],
        ),
    ):
        if hasattr(ev, "content") and ev.content and ev.content.parts:
            for p in ev.content.parts:
                if hasattr(p, "text") and p.text:
                    print(f"[{getattr(ev, 'author', '?')}] {p.text}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--bu-list-url", required=True)
    p.add_argument("--tasks", required=True)
    a = p.parse_args()
    asyncio.run(main(a.bu_list_url, json.loads(a.tasks)))
