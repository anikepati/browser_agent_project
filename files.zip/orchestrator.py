"""
SequentialOrchestrator: walks state["tasks"], invokes agents, fail-fast.

No state_mappings. Data lives in initial state.
Orchestrator just sets state["task_*"] fields per task and invokes.
"""
import json
import logging
from typing import AsyncGenerator

from typing_extensions import override
from pydantic import Field

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event
from google.genai import types as genai_types

logger = logging.getLogger(__name__)


class SequentialOrchestrator(BaseAgent):

    agent_registry: dict = Field(default_factory=dict)
    max_retries: int = 3

    @override
    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:

        state = ctx.session.state

        tasks_raw = state.get("tasks", "[]")
        tasks = json.loads(tasks_raw) if isinstance(tasks_raw, str) else tasks_raw
        if not tasks:
            yield self._evt(ctx, "No tasks.")
            return

        tracker = [
            {"idx": i, "type": t.get("type", "?"), "name": t.get("name", f"task_{i}"),
             "status": "pending", "attempt": 0, "error": ""}
            for i, t in enumerate(tasks)
        ]

        yield self._evt(ctx, f"Pipeline: {len(tasks)} tasks")

        for i, task in enumerate(tasks):
            task_type = task.get("type", "unknown")
            task_name = task.get("name", f"task_{i}")
            entry = tracker[i]

            agent = self.agent_registry.get(task_type)
            if not agent:
                entry.update(status="failed", error=f"No agent for '{task_type}'")
                self._skip(tracker, i + 1)
                yield self._evt(ctx, f"[{i+1}] FAIL: no agent for '{task_type}'")
                yield self._summary(ctx, tracker)
                return

            # Flatten task fields into state: task_name, task_parent, etc.
            for k, v in task.items():
                state[f"task_{k}"] = str(v) if v else ""

            # Clear step tracker so agent starts fresh
            state.pop(f"{agent.name}_steps", None)

            result_key = f"{agent.name}_result"
            succeeded = False
            last_error = ""

            for attempt in range(1, self.max_retries + 1):
                entry.update(status="running", attempt=attempt)
                yield self._evt(
                    ctx, f"[{i+1}/{len(tasks)}] {task_type} '{task_name}' — attempt {attempt}"
                )

                state[result_key] = ""
                # Reset step tracker for retry
                state.pop(f"{agent.name}_steps", None)

                async for event in agent.run_async(ctx):
                    yield event

                raw = state.get(result_key, "")
                if "STEP_RESULT:COMPLETED" in raw:
                    entry.update(status="completed", error="")
                    yield self._evt(ctx, f"[{i+1}] COMPLETED '{task_name}'")
                    succeeded = True
                    break
                else:
                    last_error = self._extract_error(raw)
                    entry.update(status="failed", error=last_error)
                    yield self._evt(ctx, f"[{i+1}] FAIL attempt {attempt}: {last_error}")

            if not succeeded:
                self._skip(tracker, i + 1)
                yield self._evt(ctx, f"Pipeline STOPPED: '{task_name}' failed.")
                yield self._summary(ctx, tracker)
                return

        yield self._evt(ctx, f"Pipeline COMPLETED: all {len(tasks)} tasks done.")
        yield self._summary(ctx, tracker)

    @staticmethod
    def _extract_error(raw: str) -> str:
        if not raw:
            return "No output"
        for line in reversed(raw.strip().splitlines()):
            if line.strip().startswith("STEP_RESULT:FAILED"):
                parts = line.split(":", 2)
                return parts[2].strip() if len(parts) > 2 else "failed"
        return "No STEP_RESULT"

    @staticmethod
    def _skip(tracker, from_idx):
        for j in range(from_idx, len(tracker)):
            tracker[j].update(status="skipped", error="Previous failed")

    def _summary(self, ctx, tracker):
        icons = {"completed": " OK ", "failed": "FAIL", "skipped": "SKIP",
                 "running": " >> ", "pending": " .. "}
        lines = ["── Summary ──"]
        for e in tracker:
            line = f"  [{icons.get(e['status'], '?'):>4s}] {e['idx']+1}. {e['type']} '{e['name']}'"
            if e["attempt"]:
                line += f" (x{e['attempt']})"
            if e["error"]:
                line += f" — {e['error'][:60]}"
            lines.append(line)
        return self._evt(ctx, "\n".join(lines))

    def _evt(self, ctx, text):
        return Event(
            invocation_id=ctx.invocation_id, author=self.name,
            content=genai_types.Content(
                role="model", parts=[genai_types.Part(text=text)],
            ),
        )
