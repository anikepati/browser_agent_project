"""
Agent assembly.

  SequentialOrchestrator
  ├── CreateParentBU  (LlmAgent + step tracking callback)
  └── CreateChildBU   (LlmAgent + step tracking callback)

All data in initial state. No wrappers. No nesting.
"""
import os, logging

logger = logging.getLogger(__name__)

if not os.environ.get("GOOGLE_API_KEY"):
    logger.error("GOOGLE_API_KEY not set.")

from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset, StdioServerParameters
from .step_tracking import make_tracked_agent
from .orchestrator import SequentialOrchestrator

# ═══════════════════════════════════════
# Playwright MCP
# ═══════════════════════════════════════

_dir = os.path.dirname(os.path.abspath(__file__))
STORAGE_STATE = os.getenv("PP_STORAGE_STATE", os.path.join(_dir, "storage_state.json"))
MCP_CONFIG = os.path.join(_dir, "playwright_config.json")


def _mcp_args():
    args = ["-y", "@playwright/mcp@latest"]
    if os.path.exists(MCP_CONFIG):
        args.extend(["--config", MCP_CONFIG])
    if os.path.exists(STORAGE_STATE):
        args.extend(["--isolated", f"--storage-state={STORAGE_STATE}"])
    return args


mcp = MCPToolset(
    connection_params=StdioServerParameters(command="npx", args=_mcp_args()),
    tool_filter=[
        "browser_navigate", "browser_snapshot", "browser_click",
        "browser_type", "browser_tab_list", "browser_tab_select",
        "browser_wait",
    ],
)

# ═══════════════════════════════════════
# Agents (one per task type, step tracking built in)
# ═══════════════════════════════════════

parent_bu_agent = make_tracked_agent(
    name="CreateParentBU",
    instruction_suffix="Create a Business Unit named '{task_name}'.",
    output_key="CreateParentBU_result",
    description="Creates a parent BU in Power Platform.",
    steps=[
        "Navigate to {bu_list_url}",
        "Take browser_snapshot to see the BU list",
        "Click 'New' or '+ New' in the command bar",
        "Take browser_snapshot to see the form",
        "Type '{task_name}' in the Name field",
        "Click 'Save' or 'Save & Close'",
        "Wait 5 seconds, then browser_snapshot to verify",
    ],
)
parent_bu_agent.tools = [mcp]

child_bu_agent = make_tracked_agent(
    name="CreateChildBU",
    instruction_suffix="Create a child BU named '{task_name}' under parent '{task_parent}'.",
    output_key="CreateChildBU_result",
    description="Creates a child BU with parent lookup.",
    steps=[
        "Navigate to {bu_list_url}",
        "Take browser_snapshot to see the BU list",
        "Click 'New' or '+ New' in the command bar",
        "Take browser_snapshot to see the form",
        "Type '{task_name}' in the Name field",
        "Click the 'Parent Business' lookup field",
        "Search for '{task_parent}' in the lookup",
        "Select '{task_parent}' from results",
        "Click 'Save' or 'Save & Close'",
        "Wait 5 seconds, then browser_snapshot to verify",
    ],
)
child_bu_agent.tools = [mcp]

# ═══════════════════════════════════════
# Root
# ═══════════════════════════════════════

root_agent = SequentialOrchestrator(
    name="BUPipeline",
    description="Creates BUs sequentially. Fail-fast.",
    sub_agents=[parent_bu_agent, child_bu_agent],
    agent_registry={
        "parent_bu": parent_bu_agent,
        "child_bu": child_bu_agent,
    },
    max_retries=3,
)
