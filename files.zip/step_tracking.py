"""
Step tracking for browser automation agents.

One callback does everything:
  1. Tracks which steps are done (persists in state across retries)
  2. Injects step progress into system prompt before each LLM call
  3. Keeps only the latest snapshot full, summarizes older ones

Usage:
  agent = make_tracked_agent(
      name="CreateParentBU",
      steps=[
          "Navigate to {bu_list_url}",
          "Snapshot the BU list page",
          "Click 'New' in the command bar",
          ...
      ],
      instruction_suffix="Create BU named '{task_name}'.",
      output_key="CreateParentBU_result",
  )

  # Steps use {key} resolved from state.
  # Step progress is injected via before_model_callback.
  # Agent runs all steps in ONE run_async() call.
"""
import json
import logging
from collections import defaultdict
from typing import Optional

from google.adk.agents import LlmAgent
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmResponse, LlmRequest
from google.genai import types as genai_types

logger = logging.getLogger(__name__)

MAX_SNAPSHOT_CHARS = 4000       # keep latest snapshot this size, summarize older
MAX_TOKENS_PER_TURN = 1024


def _resolve(template: str, state: dict) -> str:
    """Format {key} placeholders from state. Unknown keys become empty."""
    try:
        return template.format_map(defaultdict(str, state))
    except (KeyError, ValueError, IndexError):
        return template


def make_step_callback(agent_name: str, steps: list[str]):
    """
    Create a before_model_callback that:
      - Tracks step progress in state["{agent_name}_steps"]
      - Injects progress into system prompt
      - Summarizes old snapshots, keeps latest full
    """

    def _callback(
        callback_context: CallbackContext,
        llm_request: LlmRequest,
    ) -> Optional[LlmResponse]:

        state = callback_context.state

        # ── Initialize step tracker on first call ──
        tracker_key = f"{agent_name}_steps"
        if tracker_key not in state:
            resolved = [_resolve(s, state) for s in steps]
            tracker = [
                {"id": i, "step": s, "status": "pending", "summary": ""}
                for i, s in enumerate(resolved)
            ]
            state[tracker_key] = json.dumps(tracker)

        tracker = json.loads(state[tracker_key])

        # ── Infer completed steps from tool call history ──
        # Count successful tool responses in current context.
        # Each snapshot/navigate/click/type = roughly one step.
        tool_count = 0
        if llm_request.contents:
            for content in llm_request.contents:
                if not content.parts:
                    continue
                for part in content.parts:
                    fr = getattr(part, "function_response", None)
                    if fr and hasattr(fr, "response"):
                        tool_count += 1

        # Mark steps completed based on tool calls seen
        for i in range(min(tool_count, len(tracker))):
            if tracker[i]["status"] == "pending":
                tracker[i]["status"] = "completed"
        # Mark next pending step as "current"
        for entry in tracker:
            if entry["status"] == "pending":
                entry["status"] = "current"
                break

        state[tracker_key] = json.dumps(tracker)

        # ── Build progress text ──
        progress_lines = []
        for entry in tracker:
            if entry["status"] == "completed":
                s = entry.get("summary", "done")
                progress_lines.append(f"  [DONE] Step {entry['id']+1}: {entry['step']}")
            elif entry["status"] == "current":
                progress_lines.append(f"  [NOW ] Step {entry['id']+1}: {entry['step']}  ← DO THIS")
            else:
                progress_lines.append(f"  [    ] Step {entry['id']+1}: {entry['step']}")

        progress_block = (
            "\n\n## STEP PROGRESS\n"
            + "\n".join(progress_lines)
            + "\n\nDo the [NOW] step. Skip all [DONE] steps."
        )

        # ── Inject into system instruction ──
        cfg = llm_request.config
        if cfg and cfg.system_instruction:
            si = cfg.system_instruction
            if isinstance(si, str):
                cfg.system_instruction = si + progress_block
            elif hasattr(si, "parts") and si.parts:
                si.parts.append(genai_types.Part(text=progress_block))

        # ── Snapshot management: summarize old, keep latest full ──
        if llm_request.contents:
            snapshot_parts = []
            for content in llm_request.contents:
                if not content.parts:
                    continue
                for part in content.parts:
                    fr = getattr(part, "function_response", None)
                    if fr and hasattr(fr, "response") and isinstance(fr.response, dict):
                        # Detect snapshot responses (they're the big ones)
                        for k, v in fr.response.items():
                            if isinstance(v, str) and len(v) > MAX_SNAPSHOT_CHARS:
                                snapshot_parts.append((fr.response, k, v))

            # Keep only the LAST snapshot full, summarize older ones
            if len(snapshot_parts) > 1:
                for resp_dict, key, val in snapshot_parts[:-1]:
                    # Replace old snapshot with brief summary
                    lines = val.split("\n")[:5]
                    summary = "\n".join(lines)
                    resp_dict[key] = (
                        f"[Previous snapshot — summarized]\n{summary}\n"
                        f"...[{len(val)} chars total, truncated]"
                    )

        return None

    return _callback


def make_tracked_agent(
    name: str,
    steps: list[str],
    instruction_suffix: str = "",
    output_key: str = "",
    description: str = "",
) -> LlmAgent:
    """
    Create an LlmAgent with built-in step tracking.

    Args:
        name: Agent name (also used as state key prefix)
        steps: List of step instructions (can use {state_key} placeholders)
        instruction_suffix: Extra context appended to instruction (task-specific)
        output_key: Where to write result in state
        description: Agent description
    """
    instruction = f"""\
You are a browser automation agent. Browser is HEADED and PRE-AUTHENTICATED.
Do NOT log in. Session is already authenticated.

{instruction_suffix}

## RULES
- ONLY use browser_snapshot to read pages. NEVER browser_screenshot.
- Set expectation on browser_navigate, browser_click, browser_type to suppress auto snapshot.
- Follow the steps in STEP PROGRESS below — do the [NOW] step, skip [DONE] steps.
- After ALL steps are done, output your final line.

## OUTPUT (MANDATORY last line)
STEP_RESULT:COMPLETED
STEP_RESULT:FAILED:<reason>
"""

    return LlmAgent(
        name=name,
        model="gemini-2.0-flash",
        instruction=instruction,
        description=description or name,
        include_contents="none",
        output_key=output_key or f"{name}_result",
        before_model_callback=make_step_callback(name, steps),
        generate_content_config=genai_types.GenerateContentConfig(
            max_output_tokens=MAX_TOKENS_PER_TURN,
            temperature=0.1,
        ),
    )
